# 📚 EXAMEN FINAL DE TEORÍA - DWES 2025
## Temas 2, 3 y 4 - PHP 8.4, Base de Datos y POO

| **Información del Examen** | |
|---------------------------|---|
| **Valor** | 75% de la nota final |
| **Duración** | 2 horas (teoría + práctica) |
| **Parte Teoría** | 50 puntos |
| **Material permitido** | ❌ SIN APUNTES |
| **Fecha** | _________________ |

---

| **Alumno/a** | |
|-------------|---|
| **Nombre** | _________________________________ |
| **Apellidos** | _________________________________ |

---

# PARTE A: TEST (20 puntos - 1 punto cada pregunta)
### Marca con una X la respuesta correcta

---

## TEMA 2: PHP 8.4 Básico

### 1. ¿Cuál es la forma correcta de declarar una variable en PHP?
- [ ] a) `var $nombre = "Juan";`
- [ ] b) `$nombre = "Juan";`
- [ ] c) `let nombre = "Juan";`
- [ ] d) `nombre := "Juan";`

### 2. ¿Qué tipo de dato devuelve la expresión `3 / 2` en PHP?
- [ ] a) `int`
- [ ] b) `float`
- [ ] c) `string`
- [ ] d) `double`

### 3. ¿Cuál es la diferencia entre `==` y `===` en PHP?
- [ ] a) No hay diferencia, son equivalentes
- [ ] b) `==` compara valor y tipo, `===` solo valor
- [ ] c) `===` compara valor y tipo, `==` solo valor
- [ ] d) `===` es para strings, `==` para números

### 4. ¿Qué función se usa para obtener la longitud de un array en PHP?
- [ ] a) `length($array)`
- [ ] b) `size($array)`
- [ ] c) `count($array)`
- [ ] d) `len($array)`

### 5. ¿Cuál es la sintaxis correcta de la expresión `match` en PHP 8.4?
- [ ] a) `match($x) { 1: "uno", 2: "dos" }`
- [ ] b) `match($x) { 1 => "uno", 2 => "dos" }`
- [ ] c) `match $x { case 1: "uno"; case 2: "dos"; }`
- [ ] d) `match($x) { when 1 then "uno", when 2 then "dos" }`

### 6. ¿Qué valor devuelve `isset($variable)` si `$variable = null`?
- [ ] a) `true`
- [ ] b) `false`
- [ ] c) `null`
- [ ] d) Error de sintaxis

### 7. ¿Cuál es la forma correcta de concatenar strings en PHP?
- [ ] a) `$a + $b`
- [ ] b) `$a . $b`
- [ ] c) `$a & $b`
- [ ] d) `concat($a, $b)`

---

## TEMA 3: Acceso a Base de Datos

### 8. ¿Qué significa PDO en PHP?
- [ ] a) PHP Data Object
- [ ] b) PHP Database Operations
- [ ] c) PHP Data Objects
- [ ] d) Personal Database Objects

### 9. ¿Cuál es el modo de error recomendado para PDO en producción?
- [ ] a) `PDO::ERRMODE_SILENT`
- [ ] b) `PDO::ERRMODE_WARNING`
- [ ] c) `PDO::ERRMODE_EXCEPTION`
- [ ] d) `PDO::ERRMODE_DEBUG`

### 10. ¿Qué método de PDO se usa para obtener el ID del último registro insertado?
- [ ] a) `getLastId()`
- [ ] b) `insertId()`
- [ ] c) `lastInsertId()`
- [ ] d) `getInsertedId()`

### 11. ¿Cuál es la principal ventaja de usar prepared statements?
- [ ] a) Son más rápidos
- [ ] b) Previenen SQL Injection
- [ ] c) Usan menos memoria
- [ ] d) Son más fáciles de escribir

### 12. ¿Qué método se usa para obtener todos los resultados de una consulta SELECT?
- [ ] a) `fetch()`
- [ ] b) `fetchAll()`
- [ ] c) `getAll()`
- [ ] d) `selectAll()`

### 13. ¿Qué operación SQL se usa en una relación 1:N para unir tablas?
- [ ] a) `MERGE`
- [ ] b) `UNION`
- [ ] c) `JOIN`
- [ ] d) `CONCAT`

### 14. ¿Cuál es el propósito de `$pdo->beginTransaction()`?
- [ ] a) Iniciar una nueva conexión
- [ ] b) Iniciar un grupo de operaciones que se ejecutan como unidad
- [ ] c) Resetear la base de datos
- [ ] d) Crear una nueva tabla

---

## TEMA 4: Clases y Herencia (POO)

### 15. ¿Cuál es la visibilidad por defecto de una propiedad en PHP si no se especifica?
- [ ] a) `private`
- [ ] b) `protected`
- [ ] c) `public`
- [ ] d) Error de sintaxis (debe especificarse)

### 16. ¿Qué palabra clave se usa para heredar de una clase en PHP?
- [ ] a) `inherits`
- [ ] b) `extends`
- [ ] c) `implements`
- [ ] d) `derives`

### 17. ¿Cuál es la diferencia entre una clase abstracta y una interfaz?
- [ ] a) No hay diferencia
- [ ] b) Una clase abstracta puede tener implementación, una interfaz no (antes de PHP 8)
- [ ] c) Una interfaz puede tener propiedades, una clase abstracta no
- [ ] d) Solo se puede heredar de interfaces

### 18. ¿Qué son los Property Hooks en PHP 8.4?
- [ ] a) Funciones para validar propiedades al asignarlas o accederlas
- [ ] b) Eventos que se disparan al crear objetos
- [ ] c) Decoradores de métodos
- [ ] d) Macros de preprocesamiento

### 19. ¿Cuál es la sintaxis correcta para Asymmetric Visibility en PHP 8.4?
- [ ] a) `public(get) private(set) string $nombre`
- [ ] b) `public private(set) string $nombre`
- [ ] c) `get:public set:private string $nombre`
- [ ] d) `@visibility(public, private) string $nombre`

### 20. ¿Para qué sirven los Traits en PHP?
- [ ] a) Para crear interfaces múltiples
- [ ] b) Para reutilizar código entre clases no relacionadas por herencia
- [ ] c) Para definir constantes globales
- [ ] d) Para crear variables estáticas

---

# PARTE B: PREGUNTAS CORTAS (15 puntos - 3 puntos cada una)

### 21. Explica la diferencia entre `include` y `require` en PHP. ¿Cuándo usarías cada uno?

```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

### 22. ¿Qué es "Soft Delete" en base de datos? Escribe un ejemplo de consulta SQL que lo implemente.

```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

### 23. Explica qué es una transacción en base de datos y para qué sirven los métodos `commit()` y `rollBack()`.

```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

### 24. ¿Cuál es la diferencia entre `public`, `private` y `protected` en POO? Pon un ejemplo de cuándo usarías cada uno.

```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

### 25. Explica qué es el operador nullsafe (`?->`) en PHP 8.4 y pon un ejemplo de su uso.

```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

---

# PARTE C: CÓDIGO Y ANÁLISIS (15 puntos - 5 puntos cada pregunta)

### 26. Analiza el siguiente código e indica qué errores tiene y cómo los corregirías:

```php
<?php
class Producto {
    public $nombre;
    private $precio;
    
    public function __construct($nombre, $precio) {
        $this->nombre = $nombre;
        $this->precio = $precio;
    }
    
    private function getPrecio() {
        return $this->precio;
    }
}

$p = new Producto("Manzana", 2.50);
echo $p->getPrecio();
?>
```

**Errores encontrados y correcciones:**
```
_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________

_______________________________________________________________________________
```

---

### 27. Escribe el código PHP para conectar a una base de datos MySQL llamada "tienda" con las siguientes características:
- Host: localhost
- Puerto: 3306
- Usuario: admin
- Contraseña: secret123
- Debe configurarse para lanzar excepciones en caso de error

```php
<?php
// Escribe tu código aquí:









?>
```

---

### 28. Dado el siguiente diagrama de clases, escribe la declaración de la clase `Empleado` en PHP 8.4 usando Property Hooks:

```
┌─────────────────────────────┐
│         Empleado            │
├─────────────────────────────┤
│ - nombre: string            │
│ - salario: float (≥ 1000)   │
│ - email: string             │
├─────────────────────────────┤
│ + getNombreCompleto()       │
│ + subirSalario(porcentaje)  │
└─────────────────────────────┘
```

**Requisitos:**
- El salario mínimo es 1000 (validar al asignar)
- El nombre debe guardarse en mayúsculas
- El email es de solo lectura después de crearse

```php
<?php
// Escribe tu código aquí:













?>
```

---

# PARTE D: TEORÍA CONCEPTUAL (10 puntos)

### 29. (5 puntos) Explica los tipos de relaciones en Base de Datos (1:1, 1:N, N:M) con ejemplos del mundo real:

```
ONE-TO-ONE (1:1):
_______________________________________________________________________________

_______________________________________________________________________________

Ejemplo: ____________________________________________________________________

ONE-TO-MANY (1:N):
_______________________________________________________________________________

_______________________________________________________________________________

Ejemplo: ____________________________________________________________________

MANY-TO-MANY (N:M):
_______________________________________________________________________________

_______________________________________________________________________________

Ejemplo: ____________________________________________________________________
```

---

### 30. (5 puntos) Explica las diferencias entre **Clase Abstracta**, **Interface** y **Trait** en PHP. ¿Cuándo usarías cada uno?

```
CLASE ABSTRACTA:
¿Qué es? ________________________________________________________________________

¿Cuándo usarla? _________________________________________________________________

INTERFACE:
¿Qué es? ________________________________________________________________________

¿Cuándo usarla? _________________________________________________________________

TRAIT:
¿Qué es? ________________________________________________________________________

¿Cuándo usarlo? _________________________________________________________________

¿Puede una clase usar los tres a la vez? Explica: _________________________________

_______________________________________________________________________________
```

---

## 📊 TABLA DE PUNTUACIÓN

| Parte | Puntos Máximos | Puntos Obtenidos |
|-------|----------------|------------------|
| A - Test | 20 | |
| B - Preguntas Cortas | 15 | |
| C - Código y Análisis | 15 | |
| D - Teoría Conceptual | 10 | |
| **TOTAL TEORÍA** | **50** | |

---

> ⏰ **Recuerda:** Esta es solo la parte teórica. Después continuarás con la parte práctica donde SÍ podrás usar apuntes.
